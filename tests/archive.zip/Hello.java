import java.lang.*;
public class Hello // prints a Hello World! greeting
{ public static void main(String[] arg)
  { System.out.println("Hello World!");
  }
}
